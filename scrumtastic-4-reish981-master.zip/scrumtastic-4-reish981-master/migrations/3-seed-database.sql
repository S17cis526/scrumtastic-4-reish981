INSERT INTO projects (name, description, version, repository, license)
VALUES ("Testy", "A Test Project", "v 0.0", null, "MIT");
